# Apache-Spark-Projects
This is repository for Spark sample code and data files for the blogs I wrote for Eduprestine.


1. [Apache Spark: Sparkling star in big data firmament](http://www.edupristine.com/blog/apache-spark-vs-hadoop)
2. [Apache Spark Part -2: RDD (Resilient Distributed Dataset), Transformations and Actions](http://www.edupristine.com/blog/apache-spark-rdd-transformations-actions)
3. [Processing JSON data using Spark SQL Engine: DataFrame API](http://www.edupristine.com/blog/using-spark-sql-engine)
4. [How Apache Spark can give wings to airline analytics?](http://www.edupristine.com/blog/gathering-airlines-insights-using-apache-spark)
